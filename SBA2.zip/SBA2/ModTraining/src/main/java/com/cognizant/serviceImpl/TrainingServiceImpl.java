package com.cognizant.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.Repository.TrainingRepository;
import com.cognizant.convertor.TrainingConvertor;
import com.cognizant.entity.TrainingEntity;
import com.cognizant.interfac.TrainingDao;
import com.cognizant.interfac.TrainingService;

import com.cognizant.model.TrainingModel;

@Service
public class TrainingServiceImpl implements TrainingService{
	
	TrainingConvertor trainingConvertor = new TrainingConvertor();
	
	@Autowired 
	private TrainingRepository trainingRepo;

	@Override
	public List<TrainingModel> getUserCompletedTrainingList(int userId) {
		String status="completed";
    List<TrainingEntity> trainingList =trainingRepo.getUserCompletedTrainingList(userId, status);
		
		List<TrainingModel> completedTrainingList = new ArrayList<TrainingModel>();
		TrainingModel trainingModel = null;
		
		for(TrainingEntity entity:trainingList)
		{
			trainingModel = trainingConvertor.trainingEntityToModel(entity);
			completedTrainingList.add(trainingModel);
		}
		
		
		return completedTrainingList;
	}

	@Override
	public List<TrainingModel> getMentorCompletedTrainingList(int mentorId) {
		String status="completed";
		List<TrainingEntity> trainingList =trainingRepo.fetchMentorCompletedTrainingList(mentorId, status);
		
		List<TrainingModel> completedTrainingList = new ArrayList<TrainingModel>();
		TrainingModel trainingModel = null;
		
		for(TrainingEntity entity:trainingList)
		{
			trainingModel = trainingConvertor.trainingEntityToModel(entity);
			completedTrainingList.add(trainingModel);
		}
		
		
		return completedTrainingList;
	}

	@Override
	public List<TrainingModel> getUserCurrentTrainingList(int userId) {
		String status="current";
     List<TrainingEntity> trainingList =trainingRepo.fetchUserCurrentTrainingList(userId, status);
		
		List<TrainingModel> currentTrainingList = new ArrayList<TrainingModel>();
		TrainingModel trainingModel = null;
		
		for(TrainingEntity entity:trainingList)
		{
			trainingModel = trainingConvertor.trainingEntityToModel(entity);
			currentTrainingList.add(trainingModel);
		}
		
		
		return currentTrainingList;
		
	}

	@Override
	public List<TrainingModel> getMentorCurrentTrainingList(int mentorId) {
		String status="current";
		List<TrainingEntity> trainingList =trainingRepo.fetchMentorCurrentTrainingList(mentorId, status);  
		
		List<TrainingModel> currentTrainingList = new ArrayList<TrainingModel>();
		TrainingModel trainingModel = null;
		
		for(TrainingEntity entity:trainingList)
		{
			trainingModel = trainingConvertor.trainingEntityToModel(entity);
			currentTrainingList.add(trainingModel);
		}
		
		
		return currentTrainingList;
  }
	
}
