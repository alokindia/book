package com.cognizant.controller;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.convertor.UserConvertor;
import com.cognizant.entity.ConfirmationToken;
import com.cognizant.entity.UserEntity;
import com.cognizant.interfac.UserService;
import com.cognizant.model.MentorModel;
import com.cognizant.model.UserModel;
import com.cognizant.repository.ConfirmationTokenRepo;
import com.cognizant.repository.UserRepository;
import com.cognizant.validator.UserLoginValidator;




@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private UserLoginValidator loginValidator;
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
    private ConfirmationTokenRepo confirmationTokenRepository;
	
	ResponseEntity<Void> response = null;

	@GetMapping("/userLoginCheck")
	public ResponseEntity<Void> doUserLogin(@RequestBody UserModel userModel,Errors errors) {
		
		ValidationUtils.invokeValidator(loginValidator,userModel,errors);
		if(errors.hasErrors()){
			response=new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
		}
		else{                                                                                                                                               

			boolean status=userService.getUserLoginStatus(userModel);
			if(status) {
			response=new ResponseEntity<Void>(HttpStatus.FOUND);
			}
			else {
				response=new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
			}
		}
		return response;
	}
	

	@PostMapping("/userRegister")
	public ResponseEntity<Void> register(@RequestBody UserModel userModel) {
		
		ArrayList<UserEntity> users=new ArrayList<>();
		users.addAll(userRepo.findAll());
		UserConvertor userEntity=new UserConvertor();
		UserEntity user=new UserEntity();
		user=userEntity.userModelToEntity(userModel);
		for(UserEntity localUser:users)
		{
			if(localUser.getEmail().equals(user.getEmail()))
			{
				response=new ResponseEntity<Void>(HttpStatus.CONFLICT);
			}
			else
			{
				userService.registerUser(userModel);
        		response = new ResponseEntity<>(HttpStatus.CREATED);
			}
		}
		return response;

	}
	
	/*
	 * @GetMapping("mentorSearch/{technology}/{timingSlot}") public
	 * ResponseEntity<List<MentorModel>> search(@PathVariable("technology")String
	 * technology , @PathVariable("timingSlot")String timingSlot) {
	 * 
	 * ResponseEntity<List<MentorModel>> response = null; List<MentorModel>
	 * mentorList = userService.searchMentor(technology , timingSlot); response =
	 * new ResponseEntity<List<MentorModel>>(mentorList ,HttpStatus.OK); return
	 * response;
	 * 
	 * 
	 * }
	 */
	
	@RequestMapping(value="/confirm-account", method= {RequestMethod.GET, RequestMethod.POST})
    public ResponseEntity<Void> confirmUserAccount(@RequestParam("token")String confirmationToken)
    {
        ConfirmationToken token = confirmationTokenRepository.findByConfirmationToken(confirmationToken);

        if(token != null)
        {
            UserEntity user = userRepo.findByEmailIgnoreCase(token.getUser().getEmail());
            user.setConfirm(true);
            userService.confirmedUser(user);
            System.out.println("Confirmed");
            response = new ResponseEntity<>(HttpStatus.OK);
            
        }
        else
        {
        	response = new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        return response;
        
    }
	
	@GetMapping("/listUsers")
	public ArrayList<UserModel> listAllUsers() {
	
		ArrayList<UserModel> usersList=new ArrayList<>();
		ArrayList<UserEntity> userList=new ArrayList<>();
		userList.addAll(userService.findAllUsers());
		UserConvertor userConvertor=new UserConvertor();
		UserModel userModel=new UserModel();
		for(UserEntity entity:userList)
		{
			userModel=userConvertor.userEntityToModel(entity);
			usersList.add(userModel);
		}
		
		return usersList;
		
	}
	
	@PostMapping("/userRegister/{userId}")
	public void changingStatus(@PathVariable int userId)
	{
		userService.blocking(userId);
	}

}
