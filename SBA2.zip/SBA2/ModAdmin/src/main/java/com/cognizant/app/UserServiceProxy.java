package com.cognizant.app;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;

import com.cognizant.model.UserModel;


@FeignClient(name="netflix-zuul-api-gateway-server")
@RibbonClient(name="userservice")
public interface UserServiceProxy {
	
	@GetMapping("/userservice/user/listUsers")
	public ArrayList<UserModel> listAllUsers();
	
	@PostMapping("/userservice/user/userRegister/{userId}")
	public void changingStatus(@PathVariable int userId);

}
