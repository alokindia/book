package com.cognizant.interfac;

import java.util.ArrayList;
import java.util.List;
import com.cognizant.entity.UserEntity;
import com.cognizant.model.MentorModel;
import com.cognizant.model.UserModel;

public interface UserService {

	void registerUser(UserModel userModel);
	//List<MentorModel> searchMentor(String technology , String timingSlot);
	boolean getUserLoginStatus(UserModel userModel);
	public void confirmedUser(UserEntity user); 
	public ArrayList<UserEntity> findAllUsers();
	public void blocking(int userId);

}
