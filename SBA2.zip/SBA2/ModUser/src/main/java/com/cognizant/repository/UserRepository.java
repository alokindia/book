package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.entity.MentorEntity;
import com.cognizant.entity.UserEntity;


public interface UserRepository extends JpaRepository<UserEntity, Integer> {
	
	UserEntity findByEmailIgnoreCase(String email);
	MentorEntity fetchMentorByTech(String technology,String timingSlot);
	public UserEntity findById(int userId);
}
