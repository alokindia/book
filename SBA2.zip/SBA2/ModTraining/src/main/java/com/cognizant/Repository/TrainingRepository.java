package com.cognizant.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.entity.TrainingEntity;

public interface TrainingRepository extends JpaRepository<TrainingEntity, Integer> {
	
	public List<TrainingEntity> fetchUserCurrentTrainingList(int userId,String status);
	
	public List<TrainingEntity> fetchMentorCurrentTrainingList(int mentorId, String status);

	public List<TrainingEntity> fetchMentorCompletedTrainingList(int mentorId, String status);
	
	public List<TrainingEntity> getUserCompletedTrainingList(int userId,String status);
}
