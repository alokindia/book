package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.entity.MentorEntity;

public interface MentorRepository extends JpaRepository<MentorEntity,Integer> {
	
	MentorEntity fetchMentorByTech(String technology,String timingSlot);

}
