package com.cognizant.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.cognizant.convertor.MentorConvertor;
import com.cognizant.convertor.UserConvertor;
import com.cognizant.entity.ConfirmationToken;
import com.cognizant.entity.UserEntity;
import com.cognizant.interfac.UserService;
import com.cognizant.model.MentorModel;
import com.cognizant.model.UserModel;
import com.cognizant.repository.ConfirmationTokenRepo;
import com.cognizant.repository.UserRepository;



@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private JavaMailSender javaMail;
	
	 @Autowired
	 private ConfirmationTokenRepo confirmationTokenRepository;
	
	UserConvertor userConvertor = new UserConvertor();
	MentorConvertor mentorConvertor = new MentorConvertor();

	@Override
	public void registerUser(UserModel userModel) {
		UserEntity user = userConvertor.userModelToEntity(userModel);
		userRepo.save(user);
		
		ConfirmationToken confirmationToken = new ConfirmationToken(user);

        confirmationTokenRepository.save(confirmationToken);
        SimpleMailMessage mail= new SimpleMailMessage();
		mail.setTo(user.getEmail());
		mail.setSubject("StockMarket Email Confirmation!!");
		mail.setText("To confirm your account, please click here : "
	            +"http://localhost:8991/confirm-account?token="+
				confirmationToken.getConfirmationToken());
		javaMail.send(mail);
		System.out.println("Mail Sent");
	}
	
	

	/*
	 * @Override public List<MentorModel> searchMentor(String technology, String
	 * timingSlot) { ArrayList<MentorEntity> mentorsList= new ArrayList<>();
	 * mentorList
	 * 
	 * List<MentorEntity> mentorList = (List<MentorEntity>)
	 * userRepo.fetchMentorByTech(technology,timingSlot);
	 * 
	 * List<MentorModel> mentorModelList = new ArrayList<>(); MentorModel
	 * mentorModel = null;
	 * 
	 * for(MentorEntity mentor:mentorList) {
	 * 
	 * mentorModel = mentorConvertor.mentorEntityToModel(mentor);
	 * mentorModelList.add(mentorModel); }
	 * 
	 * return mentorModelList;
	 * 
	 * }
	 */

	@Override
	public boolean getUserLoginStatus(UserModel userModel) 
	{
		String email= userModel.getEmail();
		String password=userModel.getPassword();
		List<UserEntity> usersList=new ArrayList<>();
		usersList.addAll(userRepo.findAll());
		boolean status=false;
		for(UserEntity user:usersList)
		{
			if(user.getEmail().equalsIgnoreCase(email)&&(user.getPassword().equalsIgnoreCase(password)))
			{
				status=true;
			}
			else
			{
				status=false;
			}
		}
		return status;
	}

	@Override
	public void confirmedUser(UserEntity user) {
		userRepo.save(user);
		
	}


	@Override
	public ArrayList<UserEntity> findAllUsers() {
		ArrayList<UserEntity> listUsers=new ArrayList<>();
		listUsers.addAll(userRepo.findAll());
		return listUsers;
		
	}



	@Override
	public void blocking(int userId) {
		UserEntity user=new UserEntity();
		user=userRepo.findById(userId);
		if(user.getUserStatus()==true)
		{
			user.setUserStatus(false);
		}
		else
		{
			user.setUserStatus(true);
		}
		
		
	}
	
	

}
