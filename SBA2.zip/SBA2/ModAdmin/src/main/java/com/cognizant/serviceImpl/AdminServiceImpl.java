package com.cognizant.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cognizant.app.MentorServiceProxy;
import com.cognizant.app.UserServiceProxy;
import com.cognizant.convertor.AdminConvertor;

import com.cognizant.entity.AdminEntity;
import com.cognizant.interfac.AdminService;
import com.cognizant.model.AdminModel;
import com.cognizant.repo.AdminRepo;



@Service
public class AdminServiceImpl implements AdminService {

	
	
	@Autowired
	UserServiceProxy userServiceProxy;
	
	@Autowired
	MentorServiceProxy mentorServiceProxy;
	
	@Autowired
	private AdminRepo adminRepo;
	
	AdminConvertor adminConvertor = new AdminConvertor();

	@Override
	public boolean blockUser(int userId) {	
	    userServiceProxy.changingStatus(userId);
		return true;
	}

	@Override
	public boolean UnblockUser(int userId) {
		
		 userServiceProxy.changingStatus(userId);
			return true;
	}

	@Override
	public boolean blockMentor(int mentorId) {
	
		mentorServiceProxy.changingStatus(mentorId);
		return true;
	}

	@Override
	public boolean UnblockMentor(int mentorId) {
		
		mentorServiceProxy.changingStatus(mentorId);
		return true;
	}

	@Override
	public boolean getAdminLoginStatus(AdminModel adminModel) {
		AdminEntity adminEntity = adminConvertor.adminModelToEntity(adminModel);
		List<AdminEntity> allAdmins = adminRepo.findAll();
		for (AdminEntity admin : allAdmins)  
        { 
            if((admin.getUserName().equals(adminEntity.getUserName()))            		)
            {
            	if(admin.getPassword().equals(adminEntity.getPassword()))
            	{
            		return true;
            	}
           
            }
            else
            {
            	return false;
            	
            }
        } 
		return false;
	}

	
}
