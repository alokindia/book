package com.cognizant.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.entity.ConfirmationToken;

public interface ConfirmationTokenRepo extends CrudRepository<ConfirmationToken, String> {
    ConfirmationToken findByConfirmationToken(String confirmationToken);
}
